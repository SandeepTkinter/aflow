import os
import logging
from flask import Flask, render_template, request, flash, redirect, url_for, jsonify
from werkzeug.middleware.proxy_fix import ProxyFix
from services.airflow_client import AirflowClient
from forms import TriggerDAGForm, DAGOperationForm

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialize Airflow client
airflow_client = AirflowClient(
    base_url=os.getenv("AIRFLOW_BASE_URL", "http://localhost:8080"),
    username=os.getenv("AIRFLOW_USERNAME", "admin"),
    password=os.getenv("AIRFLOW_PASSWORD", "admin")
)

@app.route('/')
def index():
    """Main dashboard showing all DAGs"""
    try:
        dags = airflow_client.get_dags()
        return render_template('index.html', dags=dags)
    except Exception as e:
        logger.error(f"Error fetching DAGs: {str(e)}")
        flash(f"Error connecting to Airflow: {str(e)}", "danger")
        return render_template('index.html', dags=[])

@app.route('/dag/<dag_id>')
def dag_detail(dag_id):
    """DAG detail page with configuration and metadata"""
    try:
        dag = airflow_client.get_dag(dag_id)
        recent_runs = airflow_client.get_dag_runs(dag_id, limit=10)
        form = DAGOperationForm()
        return render_template('dag_detail.html', dag=dag, recent_runs=recent_runs, form=form)
    except Exception as e:
        logger.error(f"Error fetching DAG {dag_id}: {str(e)}")
        flash(f"Error fetching DAG details: {str(e)}", "danger")
        return redirect(url_for('index'))

@app.route('/dag/<dag_id>/trigger', methods=['POST'])
def trigger_dag(dag_id):
    """Trigger a DAG run"""
    form = TriggerDAGForm()
    if form.validate_on_submit():
        try:
            config = {}
            if form.config.data:
                import json
                config = json.loads(form.config.data)
            
            result = airflow_client.trigger_dag(dag_id, config)
            flash(f"DAG {dag_id} triggered successfully. Run ID: {result.get('dag_run_id', 'Unknown')}", "success")
        except Exception as e:
            logger.error(f"Error triggering DAG {dag_id}: {str(e)}")
            flash(f"Error triggering DAG: {str(e)}", "danger")
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", "danger")
    
    return redirect(url_for('dag_detail', dag_id=dag_id))

@app.route('/dag/<dag_id>/pause', methods=['POST'])
def pause_dag(dag_id):
    """Pause a DAG"""
    try:
        airflow_client.pause_dag(dag_id)
        flash(f"DAG {dag_id} paused successfully", "success")
    except Exception as e:
        logger.error(f"Error pausing DAG {dag_id}: {str(e)}")
        flash(f"Error pausing DAG: {str(e)}", "danger")
    
    return redirect(url_for('dag_detail', dag_id=dag_id))

@app.route('/dag/<dag_id>/unpause', methods=['POST'])
def unpause_dag(dag_id):
    """Unpause a DAG"""
    try:
        airflow_client.unpause_dag(dag_id)
        flash(f"DAG {dag_id} unpaused successfully", "success")
    except Exception as e:
        logger.error(f"Error unpausing DAG {dag_id}: {str(e)}")
        flash(f"Error unpausing DAG: {str(e)}", "danger")
    
    return redirect(url_for('dag_detail', dag_id=dag_id))

@app.route('/dag/<dag_id>/runs')
def dag_runs(dag_id):
    """View all runs for a specific DAG"""
    try:
        page = request.args.get('page', 1, type=int)
        limit = request.args.get('limit', 20, type=int)
        offset = (page - 1) * limit
        
        runs = airflow_client.get_dag_runs(dag_id, limit=limit, offset=offset)
        dag = airflow_client.get_dag(dag_id)
        
        return render_template('dag_runs.html', dag=dag, runs=runs, page=page, limit=limit)
    except Exception as e:
        logger.error(f"Error fetching runs for DAG {dag_id}: {str(e)}")
        flash(f"Error fetching DAG runs: {str(e)}", "danger")
        return redirect(url_for('dag_detail', dag_id=dag_id))

@app.route('/dag/<dag_id>/run/<run_id>/logs')
def dag_logs(dag_id, run_id):
    """View logs for a specific DAG run"""
    try:
        task_id = request.args.get('task_id')
        try_number = request.args.get('try_number', 1, type=int)
        
        dag = airflow_client.get_dag(dag_id)
        run = airflow_client.get_dag_run(dag_id, run_id)
        
        if task_id:
            logs = airflow_client.get_task_logs(dag_id, run_id, task_id, try_number)
            task_instances = airflow_client.get_task_instances(dag_id, run_id)
        else:
            logs = None
            task_instances = airflow_client.get_task_instances(dag_id, run_id)
        
        return render_template('dag_logs.html', 
                             dag=dag, 
                             run=run, 
                             logs=logs, 
                             task_instances=task_instances, 
                             current_task=task_id,
                             try_number=try_number)
    except Exception as e:
        logger.error(f"Error fetching logs for DAG {dag_id}, run {run_id}: {str(e)}")
        flash(f"Error fetching logs: {str(e)}", "danger")
        return redirect(url_for('dag_runs', dag_id=dag_id))

@app.route('/dag/<dag_id>/run/<run_id>/kill', methods=['POST'])
def kill_dag_run(dag_id, run_id):
    """Kill a running DAG instance"""
    try:
        airflow_client.kill_dag_run(dag_id, run_id)
        flash(f"DAG run {run_id} killed successfully", "success")
    except Exception as e:
        logger.error(f"Error killing DAG run {dag_id}/{run_id}: {str(e)}")
        flash(f"Error killing DAG run: {str(e)}", "danger")
    
    return redirect(url_for('dag_runs', dag_id=dag_id))

@app.errorhandler(404)
def not_found(error):
    return render_template('base.html', content="<h1>Page Not Found</h1><p>The requested page could not be found.</p>"), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('base.html', content="<h1>Internal Server Error</h1><p>An unexpected error occurred.</p>"), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
