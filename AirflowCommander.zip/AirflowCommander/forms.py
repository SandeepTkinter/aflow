from flask_wtf import FlaskForm
from wtforms import TextAreaField, SubmitField, SelectField, HiddenField
from wtforms.validators import Optional, ValidationError
import json

class TriggerDAGForm(FlaskForm):
    """Form for triggering DAG runs with optional configuration"""
    config = TextAreaField('Configuration (JSON)', validators=[Optional()], 
                          render_kw={"placeholder": "Optional JSON configuration for the DAG run"})
    submit = SubmitField('Trigger DAG')
    
    def validate_config(self, field):
        if field.data:
            try:
                json.loads(field.data)
            except json.JSONDecodeError:
                raise ValidationError('Invalid JSON format')

class DAGOperationForm(FlaskForm):
    """Form for DAG operations like pause/unpause"""
    operation = HiddenField()
    submit = SubmitField('Execute')
