# Overview

This is a Flask-based web application that provides a user-friendly interface for managing Apache Airflow DAGs (Directed Acyclic Graphs). The application serves as a dashboard and management tool that allows users to view, trigger, pause/unpause DAGs, monitor their execution status, and view logs through a clean web interface. It acts as a wrapper around the Airflow REST API, providing a more accessible way to interact with Airflow workflows without needing direct access to the Airflow web UI.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend uses a traditional server-side rendered approach with Flask templates and Bootstrap for styling. The application follows a classic MVC pattern where Flask routes handle requests, interact with the Airflow service layer, and render HTML templates with dynamic data. The UI is built with Bootstrap's dark theme and includes Font Awesome icons for a modern appearance. JavaScript is used minimally for form validation and UI enhancements like auto-dismissing alerts and confirmation dialogs.

## Backend Architecture
The backend is built on Flask with a service-oriented architecture. The main application logic is separated into distinct layers:
- **Route handlers** in `app.py` manage HTTP requests and responses
- **Service layer** (`AirflowClient`) encapsulates all interactions with the Airflow REST API
- **Forms layer** handles form validation and data binding using Flask-WTF
- **Template layer** renders HTML responses using Jinja2 templates

The application uses session-based state management with Flask's built-in session handling. Error handling is implemented throughout with proper logging and user-friendly error messages displayed via Flask's flash messaging system.

## Data Storage Solutions
The application does not maintain its own persistent data storage. Instead, it relies entirely on the external Airflow instance for all DAG-related data. All information about DAGs, runs, tasks, and logs is fetched in real-time from the Airflow REST API. Session data is stored in Flask's session mechanism (server-side by default).

## Authentication and Authorization
Authentication is handled through HTTP Basic Auth when communicating with the Airflow API. The application stores Airflow credentials (username/password) as environment variables and uses them to authenticate all API requests. The Flask application itself does not implement user authentication - it assumes it's running in a trusted environment or behind a reverse proxy that handles authentication.

# External Dependencies

## Airflow Integration
The core external dependency is an Apache Airflow instance accessible via its REST API. The application expects:
- Airflow REST API v1 endpoints to be available
- HTTP Basic Authentication enabled on the Airflow instance
- Network connectivity between the Flask app and Airflow server

## Third-party Libraries
- **Flask**: Web framework providing routing, templating, and session management
- **Flask-WTF**: Form handling and CSRF protection
- **WTForms**: Form validation and rendering
- **Requests**: HTTP client library for Airflow API communication
- **Werkzeug**: WSGI utilities including ProxyFix middleware

## Frontend Dependencies
- **Bootstrap**: CSS framework for responsive UI components
- **Font Awesome**: Icon library for UI elements
- **Prism.js**: Syntax highlighting for code blocks and logs

The application is designed to be environment-agnostic and configures itself through environment variables for Airflow connection details, making it suitable for deployment in various environments from development to production.