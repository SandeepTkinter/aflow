import requests
from requests.auth import HTTPBasicAuth
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)

class AirflowClient:
    """Client for interacting with Airflow REST API"""
    
    def __init__(self, base_url: str, username: str, password: str):
        self.base_url = base_url.rstrip('/')
        self.auth = HTTPBasicAuth(username, password)
        self.session = requests.Session()
        self.session.auth = self.auth
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """Make a request to the Airflow API"""
        url = f"{self.base_url}/api/v1/{endpoint}"
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.RequestException as e:
            logger.error(f"Airflow API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                try:
                    error_detail = e.response.json()
                    raise Exception(f"Airflow API Error: {error_detail.get('detail', str(e))}")
                except:
                    raise Exception(f"Airflow API Error: {e.response.status_code} - {e.response.text}")
            raise Exception(f"Failed to connect to Airflow: {str(e)}")
    
    def get_dags(self, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """Get list of all DAGs"""
        params = {'limit': limit, 'offset': offset}
        response = self._make_request('GET', 'dags', params=params)
        return response.get('dags', [])
    
    def get_dag(self, dag_id: str) -> Dict[str, Any]:
        """Get details of a specific DAG"""
        return self._make_request('GET', f'dags/{dag_id}')
    
    def get_dag_runs(self, dag_id: str, limit: int = 25, offset: int = 0, 
                     state: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get DAG runs for a specific DAG"""
        params = {'limit': limit, 'offset': offset}
        if state:
            params['state'] = state
        
        response = self._make_request('GET', f'dags/{dag_id}/dagRuns', params=params)
        return response.get('dag_runs', [])
    
    def get_dag_run(self, dag_id: str, run_id: str) -> Dict[str, Any]:
        """Get details of a specific DAG run"""
        return self._make_request('GET', f'dags/{dag_id}/dagRuns/{run_id}')
    
    def trigger_dag(self, dag_id: str, config: Dict[str, Any] = None) -> Dict[str, Any]:
        """Trigger a new DAG run"""
        data = {}
        if config:
            data['conf'] = config
        
        return self._make_request('POST', f'dags/{dag_id}/dagRuns', json=data)
    
    def pause_dag(self, dag_id: str) -> Dict[str, Any]:
        """Pause a DAG"""
        data = {'is_paused': True}
        return self._make_request('PATCH', f'dags/{dag_id}', json=data)
    
    def unpause_dag(self, dag_id: str) -> Dict[str, Any]:
        """Unpause a DAG"""
        data = {'is_paused': False}
        return self._make_request('PATCH', f'dags/{dag_id}', json=data)
    
    def kill_dag_run(self, dag_id: str, run_id: str) -> Dict[str, Any]:
        """Kill/terminate a DAG run"""
        data = {'state': 'failed'}
        return self._make_request('PATCH', f'dags/{dag_id}/dagRuns/{run_id}', json=data)
    
    def get_task_instances(self, dag_id: str, run_id: str) -> List[Dict[str, Any]]:
        """Get task instances for a DAG run"""
        response = self._make_request('GET', f'dags/{dag_id}/dagRuns/{run_id}/taskInstances')
        return response.get('task_instances', [])
    
    def get_task_logs(self, dag_id: str, run_id: str, task_id: str, 
                      try_number: int = 1) -> str:
        """Get logs for a specific task instance"""
        try:
            # Try to get logs from the logs endpoint
            endpoint = f'dags/{dag_id}/dagRuns/{run_id}/taskInstances/{task_id}/logs/{try_number}'
            
            # For logs, we want the raw text response
            url = f"{self.base_url}/api/v1/{endpoint}"
            response = self.session.get(url)
            
            if response.status_code == 200:
                # Check if response is JSON (error) or text (logs)
                try:
                    json_response = response.json()
                    # If it's JSON, it might contain the log content
                    if 'content' in json_response:
                        return json_response['content']
                    else:
                        return str(json_response)
                except:
                    # If it's not JSON, it's likely the raw log content
                    return response.text
            else:
                response.raise_for_status()
                
        except Exception as e:
            logger.error(f"Error fetching logs: {e}")
            return f"Error fetching logs: {str(e)}"
    
    def get_dag_source(self, dag_id: str) -> str:
        """Get DAG source code"""
        try:
            response = self._make_request('GET', f'dags/{dag_id}/details')
            return response.get('file_token', 'Source not available')
        except Exception as e:
            return f"Error fetching source: {str(e)}"
