// Main JavaScript for Airflow DAG Manager

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));

    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Form validation for trigger DAG modal
    const triggerForm = document.querySelector('#triggerModal form');
    if (triggerForm) {
        triggerForm.addEventListener('submit', function(e) {
            const configTextarea = triggerForm.querySelector('textarea[name="config"]');
            if (configTextarea && configTextarea.value.trim()) {
                try {
                    JSON.parse(configTextarea.value);
                } catch (err) {
                    e.preventDefault();
                    alert('Invalid JSON configuration. Please check your syntax.');
                    configTextarea.focus();
                    return false;
                }
            }
        });
    }

    // Add confirmation to dangerous operations
    const dangerousForms = document.querySelectorAll('form[action*="kill"], form[action*="pause"]');
    dangerousForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const action = form.action;
            let message = 'Are you sure you want to perform this action?';
            
            if (action.includes('kill')) {
                message = 'Are you sure you want to kill this DAG run? This action cannot be undone.';
            } else if (action.includes('pause')) {
                message = 'Are you sure you want to pause this DAG?';
            }
            
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });

    // Auto-refresh for pages with running content
    const autoRefreshPages = ['dag_detail', 'dag_runs', 'dag_logs'];
    const currentPath = window.location.pathname;
    
    if (autoRefreshPages.some(page => currentPath.includes(page))) {
        // Check if there are any running DAGs or tasks
        const runningElements = document.querySelectorAll('.badge:contains("running"), .badge[class*="bg-primary"]');
        if (runningElements.length > 0) {
            // Set up auto-refresh every 30 seconds for pages with running content
            setTimeout(() => {
                location.reload();
            }, 30000);
        }
    }

    // Enhance table interactions
    const tables = document.querySelectorAll('.table');
    tables.forEach(table => {
        // Make rows clickable if they contain action links
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            const firstLink = row.querySelector('a');
            if (firstLink && !row.classList.contains('clickable-row')) {
                row.classList.add('clickable-row');
                row.style.cursor = 'pointer';
                row.addEventListener('click', function(e) {
                    // Don't trigger if clicking on buttons or links
                    if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A' || e.target.closest('button') || e.target.closest('a')) {
                        return;
                    }
                    firstLink.click();
                });
            }
        });
    });

    // Status badge styling improvements
    const statusBadges = document.querySelectorAll('.badge');
    statusBadges.forEach(badge => {
        const text = badge.textContent.toLowerCase();
        if (text.includes('success')) {
            badge.innerHTML = '<i class="fas fa-check me-1"></i>' + badge.textContent;
        } else if (text.includes('failed')) {
            badge.innerHTML = '<i class="fas fa-times me-1"></i>' + badge.textContent;
        } else if (text.includes('running')) {
            badge.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>' + badge.textContent;
        } else if (text.includes('queued')) {
            badge.innerHTML = '<i class="fas fa-clock me-1"></i>' + badge.textContent;
        }
    });

    // Copy functionality for code elements
    const codeElements = document.querySelectorAll('code.user-select-all');
    codeElements.forEach(code => {
        code.addEventListener('click', function() {
            navigator.clipboard.writeText(code.textContent).then(() => {
                // Visual feedback
                const original = code.style.backgroundColor;
                code.style.backgroundColor = 'var(--bs-success)';
                setTimeout(() => {
                    code.style.backgroundColor = original;
                }, 500);
            });
        });
        code.title = 'Click to copy';
    });
});

// Helper function to format dates consistently
function formatDate(dateString) {
    if (!dateString) return 'N/A';
    try {
        const date = new Date(dateString);
        return date.toLocaleString();
    } catch (e) {
        return dateString;
    }
}

// Helper function to calculate duration between dates
function calculateDuration(startDate, endDate) {
    if (!startDate || !endDate) return null;
    try {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const diff = end - start;
        
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);
        
        if (hours > 0) {
            return `${hours}h ${minutes}m ${seconds}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${seconds}s`;
        } else {
            return `${seconds}s`;
        }
    } catch (e) {
        return null;
    }
}

// Loading state helper
function showLoading(element) {
    const spinner = document.createElement('div');
    spinner.className = 'spinner-border spinner-border-sm me-2';
    spinner.setAttribute('role', 'status');
    element.prepend(spinner);
    element.disabled = true;
}

function hideLoading(element) {
    const spinner = element.querySelector('.spinner-border');
    if (spinner) {
        spinner.remove();
    }
    element.disabled = false;
}
